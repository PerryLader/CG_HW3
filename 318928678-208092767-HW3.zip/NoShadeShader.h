#pragma once
#include "Shader.h"
class NoShadeShader :
    public Shader
{
    void scanConvertion() override;
};

